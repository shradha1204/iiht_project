package com.javasampleapproach.springrest.mysql.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javasampleapproach.springrest.mysql.model.MentorSkill;
import com.javasampleapproach.springrest.mysql.model.Technology;
import com.javasampleapproach.springrest.mysql.model.User;
import com.javasampleapproach.springrest.mysql.repo.MentorRepository;
import com.javasampleapproach.springrest.mysql.repo.MentorSkillRepository;
import com.javasampleapproach.springrest.mysql.repo.TechnologyRepository;
import com.javasampleapproach.springrest.mysql.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepo;
	
	@Autowired
	MentorRepository mentorRepo;
	
	@Autowired
	MentorSkillRepository mentorSkillRepo;
	
	@Autowired
	TechnologyRepository technologyRepo;
	

	
	@Override
	public Optional<User> findByEmailAndPassword(String username,String password) {
		Optional<User> user=userRepo.findByEmailAndPassword(username,password);
		return user;
	}

	

	@Override
	public List<Technology> findAllTechnologies() {
		// TODO Auto-generated method stub
		List<Technology> technologies=technologyRepo.findAll();
		return technologies;
	}

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		double x=Math.random();
		x=x*10000;
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		   String str=dtf.format(now);
		   
		User _user=userRepo.save(new User(user.getFirstName(),user.getLastName(),user.getEmail(),user.getPassword(), user.getContactNumber(),
				str,x,user.getAddress()));
		return user;
	}



	@Override
	public Optional<User> findById(Long id) {
		// TODO Auto-generated method stub
		Optional<User> _user=userRepo.findById(id);
		return _user;
	}



	@Override
	public List<MentorSkill> findTechnology_name() {
		List<MentorSkill> ms=mentorSkillRepo.findAll();
		return ms;
	}



	@Override
	public List<MentorSkill> getTimeOfCourse(String technologyName) {
		List<MentorSkill> ms=mentorSkillRepo.findTimeOfCourse(technologyName);
		
		return ms;
	}



	@Override
	public List<MentorSkill> getMentorDetails(String technologyName,String timeOfCourse,String startDate) {
		List<MentorSkill> ms=mentorSkillRepo.findMentorDetails(technologyName,timeOfCourse,startDate);
		return ms;
	}



	
	  @Override public List<MentorSkill> getOngoingTrainings(String username,
	 String password, String status) { Optional<User> user=userRepo.findByEmailAndPassword(username,password);
	 List<MentorSkill> ms=new ArrayList<>();
	 User u=user.get();
	 ms.addAll(mentorSkillRepo.findOngoingTrainings(u.getId() ,status)); return ms; }
	 
	  @Override public List<MentorSkill> getCompletedTrainings(String username,
				 String password, String status) { Optional<User> user=userRepo.findByEmailAndPassword(username,password);
				 List<MentorSkill> ms=new ArrayList<>();
				 User u=user.get();
				 ms.addAll(mentorSkillRepo.findCompletedTrainings(u.getId() ,status));
				 
				 return ms; 
				 }
				 
	


	/*
	 * @Override public List<MentorSkill> getTimeOfCourse(String technologyName) {
	 * List<MentorSkill> ms=mentorSkillRepo.findByTechnologyName(technologyName);
	 * System.out.println(ms); return ms; }
	 */

}
