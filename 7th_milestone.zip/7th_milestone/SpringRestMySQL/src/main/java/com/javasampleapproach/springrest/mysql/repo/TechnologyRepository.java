package com.javasampleapproach.springrest.mysql.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javasampleapproach.springrest.mysql.model.Technology;

public interface TechnologyRepository extends JpaRepository<Technology, Long> {

	
	

}
