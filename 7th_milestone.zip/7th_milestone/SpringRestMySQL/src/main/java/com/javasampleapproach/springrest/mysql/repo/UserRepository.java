package com.javasampleapproach.springrest.mysql.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.javasampleapproach.springrest.mysql.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

	
	Optional<User> findByEmailAndPassword(String username, String password);

	
	

}
