package com.javasampleapproach.springrest.mysql.controller;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.springrest.mysql.model.MentorSkill;

import com.javasampleapproach.springrest.mysql.model.User;
import com.javasampleapproach.springrest.mysql.service.UserService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping("/user/{username}/{password}")
	Optional<User> getUser(@PathVariable("username") String username, @PathVariable("password") String password)
	{
		Optional<User> user=userService.findByEmailAndPassword(username,password);
		return user;
		
	}

	/*
	 * @GetMapping("/user/{id}") Optional<User> getUser(@PathVariable("id") long id
	 * ) { Optional<User> user=userService.findById(id); return user;
	 * 
	 * }
	 */
	@GetMapping("/user/getTechnologyName")
	List<MentorSkill> getTechnologyName()
	{
		List<MentorSkill> ms=userService.findTechnology_name();
		return ms;
		
	}
	@GetMapping("/user/{technologyName}/{timeOfCourse}/{startDate}")
	List<MentorSkill> getMentorDetails(@PathVariable("technologyName") String technologyName,@PathVariable("timeOfCourse") String timeOfCourse,
			@PathVariable("startDate") String startDate)
	{
		List<MentorSkill> ms=userService.getMentorDetails(technologyName,timeOfCourse,startDate);
		return ms;
		
	}
	
	
	
	 @GetMapping("/user/getOngoingTrainings/{username}/{password}/{status}") List<MentorSkill>
	 getOngoingTrainings(@PathVariable("username") String
	 username,@PathVariable("password") String password,
	  
	 @PathVariable("status") String status) { 
		 System.out.println("Ongoing");
		 List<MentorSkill>
	 ms=userService.getOngoingTrainings(username,password,status); return ms;
	 
	 }
	 
	 @GetMapping("/user/getCompletedTrainings/{username}/{password}/{status}") List<MentorSkill>
	 getCompletedTrainings(@PathVariable("username") String
	 username,@PathVariable("password") String password,
	  
	 @PathVariable("status") String status) { 
		 System.out.println("Completed");
		 List<MentorSkill>
	 ms=userService.getCompletedTrainings(username,password,status); return ms;
	 
	 }
	 
	 
	
	@GetMapping("/user/{technologyName}")
	List<MentorSkill> getTrainings(@PathVariable("technologyName") String technologyName)
	{
		List<MentorSkill> ms=userService.getTimeOfCourse(technologyName);
		return ms;
		
	}
	
	@PostMapping(value = "/user/create")
	public User postCustomer(@RequestBody User user) {

		User _user = userService.createUser(user);
		return _user;
	}


}
