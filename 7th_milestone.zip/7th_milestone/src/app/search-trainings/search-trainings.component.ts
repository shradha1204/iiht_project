import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute,Router, Params} from '@angular/router';
import { User } from '../user';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MentorSkill } from '../mentorskill';
@Component({
  selector: 'app-search-trainings',
  templateUrl: './search-trainings.component.html',
  styleUrls: ['./search-trainings.component.css']
})
export class SearchTrainingsComponent implements OnInit {

  user:User;
  technologyName:string;
  timeOfCourse:string;
  startDate:string;
  mentorSkill:MentorSkill[];
  mentorSkill2:MentorSkill[];
  mentorSkill3:MentorSkill[];
  searchTrainingsForm:FormGroup;
  isLangSelected:boolean=true;
  constructor(private route:ActivatedRoute,private userService:UserService,private router:Router) { 
    
    this.searchTrainingsForm=new FormGroup({
      technologyName:new FormControl('',Validators.required),
      timeOfCourse:new FormControl({value:'',disabled: true},Validators.required),
      startDate:new FormControl({value:'',disabled: true},Validators.required),
      
    })
  }

  ngOnInit() {
    this.route.params.subscribe((params: Params)=>{
      let username=params['username'];
      let password=params['password'];
  
      this.userService.getUserAfterLogin(username,password)
      .subscribe(user=>this.user=user);
      
      // console.log(username,password);
  
    });
    this.userService.getTechnologyName()
    .subscribe(mentorSkill=>{this.mentorSkill=mentorSkill;
      
    })
  
   
  }
  searchTrainings()
  {
    this.searchTrainingsForm.get('timeOfCourse').enable();
    this.userService.getToc(this.technologyName)
      .subscribe(mentorSkill2=>{this.mentorSkill2=mentorSkill2;
        // console.log(this.technologyName);
        // console.log(this.mentorSkill2);
      })
      
  }
  searchTimeOfCourse()
  {
    this.searchTrainingsForm.get('startDate').enable();
    
  }
  onSubmit()
  {
   
    this.userService.getMentorDetails(this.technologyName,this.timeOfCourse,this.startDate)
    .subscribe(mentorSkill3=>{this.mentorSkill3=mentorSkill3;
      
    })
  }

}
