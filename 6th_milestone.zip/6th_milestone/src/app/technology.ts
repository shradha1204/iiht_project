export class Technology {
    id: number;
    technology_name:string;
    toc:string;
    fees:number;
    duration:number;
    prerequites:string;
}

