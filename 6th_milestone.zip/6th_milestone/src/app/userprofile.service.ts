import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserprofileService {

  private baseUrl = 'http://localhost:9558/api/users';

  constructor(private http: HttpClient) { }

  
  getUsersByEmail(email: string): Observable<any> {
    // console.log(this.http.get(`${this.baseUrl}/email/${email}`));
    // console.log(email);
    return this.http.get(`${this.baseUrl}/email/${email}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/delete`, { responseType: 'text' });
  }

  createUser(user: Object): Observable<any> {
    return this.http.post(`${this.baseUrl}` + `/create`, user);
  }

}
