import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomersListComponent } from './customers-list/customers-list.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { SearchCustomersComponent } from './search-customers/search-customers.component';
import { SearchnoCustomerComponent } from './searchno-customer/searchno-customer.component';
import { UserprofileComponent} from './userprofile/userprofile.component';
import { MycourseComponent } from './mycourse/mycourse.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { UserlandingComponent } from './userlanding/userlanding.component';
import { MentorlandingComponent } from './mentorlanding/mentorlanding.component';
import { LoginComponent } from './login/login.component';
import { MentorregistercourseComponent } from './mentorregistercourse/mentorregistercourse.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
 
const routes: Routes = [
   { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'customer', component: CustomersListComponent },
    { path: 'userlanding/add', component: CreateCustomerComponent },
    { path: 'findbyage', component: SearchCustomersComponent },
    { path: 'userlanding/userprofile', component: UserprofileComponent},
    { path: 'findbynumber', component: SearchnoCustomerComponent},
    {path: 'userlanding/mycourse',component: MycourseComponent},
    {path: 'login',component: LoginComponent},
    {path: 'userlanding/:username/:password',component:UserlandingComponent},
    {path: 'mentorlanding',component:MentorlandingComponent},
    {path: 'mentorlanding/:username/:password',component:MentorlandingComponent},
    {path: 'usersignup', component: UsersignupComponent},
    {path: 'mentorregistercourse', component: MentorregistercourseComponent},
    {path: 'userlanding/register',component: UsersignupComponent},
     {path: 'mentorsignup',component: MentorsignupComponent},
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
