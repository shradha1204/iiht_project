import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchnoCustomerComponent } from './searchno-customer.component';

describe('SearchnoCustomerComponent', () => {
  let component: SearchnoCustomerComponent;
  let fixture: ComponentFixture<SearchnoCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchnoCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchnoCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
