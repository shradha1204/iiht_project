import { Component, OnInit } from '@angular/core';
import { Userprofile } from '../userprofile';
import { UserprofileService } from '../userprofile.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usersignup',
  templateUrl: './usersignup.component.html',
  styleUrls: ['./usersignup.component.css']
})
export class UsersignupComponent implements OnInit {
  user: Userprofile = new Userprofile();
  submitted = false;
  constructor(private router:Router,private userService: UserprofileService) { }

  ngOnInit() {
  }

  newUser() : void{
    this.submitted=false;
    this.user = new Userprofile();
  }

  save()
  {

    this.userService.createUser(this.user).subscribe(user => this.user=user);
    this.user=new Userprofile();
    this.router.navigate(['']);
  }
  onSubmit()
  {
    this.save();
    this.submitted=true;
    
  }


}
