import { Component, OnInit } from '@angular/core';
import { Userprofile } from '../userprofile';
import { UserprofileService } from '../userprofile.service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  email: string='aksaht@gmail.com';
  users: Userprofile;

  constructor(private dataService: UserprofileService) { }

  ngOnInit() {
    
    this.userdetails();
  }

  private userdetails() {
    // console.log(this.email);
    this.dataService.getUsersByEmail(this.email)
          .subscribe(users => this.users = users);
        
  }

  
}
