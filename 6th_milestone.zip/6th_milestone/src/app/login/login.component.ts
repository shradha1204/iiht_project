import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Mentor } from '../mentor';
import { LoginService } from '../login.service';
import { Userprofile } from '../userprofile';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  mentors:Mentor;
  users:Userprofile;
  Musername:string;
  Mpassword:string;
  Uusername:string;
  Upassword:string;

  constructor(private router:Router, private loginservice: LoginService) { }
  ngOnInit() {
  }
  goToSignup()
  {
    this.router.navigate(['usersignup']);
  }
onLoginUser()
{
  this.loginservice.getUserAfterLogin(this.Uusername,this.Upassword).subscribe(users => {this.users=users;
    if(this.users!=null)
    this.router.navigate(['userlanding',this.Uusername,this.Upassword]);});
    
}

  goToMentorLogin()
  {
    this.router.navigate(['mentorlanding']);
  }
  goToMentorSignup()
  {
    this.router.navigate(['mentorsignup']);
  }
  onLoginMentor()
  {
   this.loginservice.getMentorAfterLogin(this.Musername,this.Mpassword)
   .subscribe(mentors=>{this.mentors=mentors;
  if(this.mentors!=null)
this.router.navigate(['mentorlanding',this.Musername,this.Mpassword]);});
  }

}
