import { Component, OnInit } from '@angular/core';

//import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { Technology } from '../technology';

@Component({
  selector: 'create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css']
})
export class CreateCustomerComponent implements OnInit {

  
  technology : Technology[];

  
  constructor(private customerService: CustomerService) { }

  ngOnInit() {
    this.save();
  }


  save() {
    this.customerService.getTechnologyList()
      .subscribe(technology=>this.technology=technology, error => console.log(error));

  }

}
