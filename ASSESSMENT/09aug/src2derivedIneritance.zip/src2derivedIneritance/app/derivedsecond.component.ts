import { Component } from '@angular/core';
import { BaseComponent } from './base.component';

@Component({
  selector : 'my-inherited2',
  template: `
    <div>
      Base2 Component {{isBase}}!
    </div>
  `
})
export class DerivedsecondComponent extends BaseComponent {}