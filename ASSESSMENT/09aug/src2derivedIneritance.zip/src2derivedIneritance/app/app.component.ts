import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <div>
      <my-base></my-base>
      <hr />
      <my-inherited [isBase]="false"></my-inherited>
      <hr/>
      <my-inherited2 [isBase]="false"></my-inherited2>
      
    </div>
  `
})
export class AppComponent { }