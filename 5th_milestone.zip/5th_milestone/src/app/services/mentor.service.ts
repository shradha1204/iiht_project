import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IMentor } from '../components/models/mentor.model';



const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor(private http:HttpClient) { }

  getMentors() {
    return this.http.get('/server/api/mod/mentor');
    
  }

  getMentorById(id:number) {
    return this.http.get('/server/api/mod/mentor/id/'+id);
  }

  getMentor(name: String) {
    return this.http.get('/server/api/mod/mentor/'+name);
  }

  createMentor(mentor:IMentor) {
    let body = JSON.stringify(mentor);
    
    return this.http.post('server/api/mod/mentor/new',body, httpOptions);
  }
 
  
  
  blockMentor(mentor:IMentor) {
    let body = JSON.stringify(mentor)
    
    console.log(body);
    return this.http.post('server/api/mod/mentor/block/'+mentor.id,body,httpOptions);
  }

  unblockMentor(mentor:IMentor) {
    let body = JSON.stringify(mentor)
    console.log(body);
    return this.http.post('server/api/mod/mentor/unblock/'+mentor.id,body,httpOptions);
  }

}
