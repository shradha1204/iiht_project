import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

import { ITechnology } from '../components/models/technology.model';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class TechnologyService {

  constructor(private http:HttpClient) { }

  createTechnology(technology) {
    let body = JSON.stringify(technology);
    return this.http.post('server/api/mod/technology/new',body, httpOptions);
  }

  getTechnologies() {
    return this.http.get('/server/api/mod/technology');
    
  }
}
