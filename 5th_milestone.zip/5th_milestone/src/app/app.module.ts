import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MentorListComponent } from './components/mentor-list/mentor-list.component';
import { MentorService } from './services/mentor.service';
import { HttpClientModule } from '@angular/common/http';
import { MentorThumbnailComponent } from './components/mentor-list/mentor-thumbnail.component';
import { NavBarComponent } from './components/nav/navbar.component';
import { MentorDetailsComponent } from './components/mentor-details/mentor-details.component';
import { CreateMentorComponent } from './components/create/create-mentor.component';
import { CreateTechnologyComponent } from './components/create/create-technology.component';
import { Error404Component } from './components/errors/404.component';
import { MentorRouteActivator } from './components/mentor-details/mentor-route-activator.service';
import { RouterModule } from '@angular/router';
import { AdminLoginComponent } from './components/login/admin-login.component';
import { FormsModule } from '@angular/forms'
import { TechnologyService } from './services/technology.service';
import { TechnologyListComponent } from './components/technology-list/technology-list.component';
import { TechnologyThumbnailComponent } from './components/technology-list/technology-thumbnail.component';

@NgModule({
  declarations: [
    AppComponent,
    MentorListComponent,
    MentorThumbnailComponent,
    NavBarComponent,
    MentorDetailsComponent,
    CreateMentorComponent,
    CreateTechnologyComponent,
    Error404Component,
    AdminLoginComponent,
    TechnologyListComponent,
    TechnologyThumbnailComponent
    
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [MentorService, MentorRouteActivator, TechnologyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
