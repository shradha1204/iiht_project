import { Injectable } from "@angular/core";
import { Router, CanActivate, ActivatedRouteSnapshot } from "@angular/router"
import { MentorService } from 'src/app/services/mentor.service';
@Injectable() 
export class MentorRouteActivator implements CanActivate{
    
    constructor(private mentorService: MentorService, private router: Router) {

    }
    canActivate(route: ActivatedRouteSnapshot) {
        
        const mentorExists = !!this.mentorService.getMentorById(route.params['id'])
        if(!mentorExists)
            this.router.navigate(['/404'])
        return mentorExists
}

}