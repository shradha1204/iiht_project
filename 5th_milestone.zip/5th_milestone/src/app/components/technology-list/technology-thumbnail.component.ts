import { Component, Input, Output, EventEmitter } from "@angular/core";

import { Router } from '@angular/router';

import { ITechnology } from '../models/technology.model';


@Component({
    selector: 'technology-thumbnail',
    template: `
    <div>
        <div class="well hoverwell thumbnail">
             <h2>{{ technology1?.name }}</h2>
             <div> Time of Course: {{technology1?.toc}} </div>
             <div> Fees: {{technology1?.fees }} </div>
             <div> Duration: {{technology1?.duration}} </div>
             <div> Prerequisites: {{technology1?.prerequites}} </div>
        </div>
       
    </div>


    `,
    styles: [`
        .well div { color:#bbb;}
        .height-gap {margin-top: 10px;}
        .btn-group div{float:right;}
    `]

})

export class TechnologyThumbnailComponent {
    
    @Input() technology1: ITechnology;
    
    
    constructor(private router: Router){
        
    }
   

}