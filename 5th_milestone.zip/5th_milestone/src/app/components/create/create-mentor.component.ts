import { Component, OnInit } from "@angular/core";
import { IMentor } from '../models/mentor.model';
import { FormGroup } from '@angular/forms';
import { MentorService } from 'src/app/services/mentor.service';
import { Router } from '@angular/router';

@Component({
    templateUrl: './create-mentor.component.html',
    styles: [`
        em {float:right; color:#E05C65; padding-left:10px; }
        .error input { background-color: #E3C3C5;}
        .error ::-webkit-input-placeholder { color: #999;}
        .error ::-moz-placeholder { color: #999;}
        .error :-mox-placeholder { color: #999;}
        .error :ms-input-placeholder { color: #999;}
    `]
})
export class CreateMentorComponent implements OnInit{
    public technology:IMentor
    mentorForm: FormGroup
    constructor(private mentorService: MentorService, private router: Router){
    
    }

    ngOnInit(){
        this.mentorForm = new FormGroup({

        })
    }
    cancel() {
        this.router.navigate(['/mentors'])
    }

    saveMentor(formValues) {
        console.log(formValues)
        this.mentorService.createMentor(formValues).subscribe(
            data => this.mentorForm.reset(),
            error => console.error(error),
            () => console.log('mentor added')
            
        )
        this.router.navigate(['/mentors'])
    }
}