import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';
import { TechnologyService } from 'src/app/services/technology.service';
import { ITechnology } from '../models/technology.model';
import { FormGroup } from '@angular/forms';

@Component({
    templateUrl: './create-technology.component.html',
    styles: [`
        em {float:right; color:#E05C65; padding-left:10px; }
        .error input { background-color: #E3C3C5;}
        .error ::-webkit-input-placeholder { color: #999;}
        .error ::-moz-placeholder { color: #999;}
        .error :-mox-placeholder { color: #999;}
        .error :ms-input-placeholder { color: #999;}
    `]
})

export class CreateTechnologyComponent implements OnInit{
    public technology:ITechnology
    techForm: FormGroup
    constructor(private technologyService: TechnologyService, private router: Router){
    
    }

    ngOnInit(){
        this.techForm = new FormGroup({

        })
    }
    cancel() {
        this.router.navigate(['/mentors'])
    }

    saveTechnology(formValues) {
        console.log(formValues)
        this.technologyService.createTechnology(formValues).subscribe(
            data => this.techForm.reset(),
            error => console.error(error),
            () => console.log('technology added')
            
        )
        this.router.navigate(['/mentors'])
    }
}