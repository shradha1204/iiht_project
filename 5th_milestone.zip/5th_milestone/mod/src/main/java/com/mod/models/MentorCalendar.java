package com.mod.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "Mentor_Calendar")
public class MentorCalendar implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="time_of_course")
    private String timeOfCourse;
    
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="mentor_id",unique = true)
	private Mentor mentor;
    
    @Temporal(TemporalType.DATE)
    @Column(name="start_date")
    Date statDate;
    
    @Temporal(TemporalType.DATE)
    @Column(name="end_date")
    Date endDate;
  


	public Long getId() {
		return id;
	}



	public String getTimeOfCourse() {
		return timeOfCourse;
	}



	public void setTimeOfCourse(String timeOfCourse) {
		this.timeOfCourse = timeOfCourse;
	}



	public Mentor getMentor() {
		return mentor;
	}



	public void setMentor(Mentor mentor) {
		this.mentor = mentor;
	}



	public Date getStatDate() {
		return statDate;
	}



	public void setStatDate(Date statDate) {
		this.statDate = statDate;
	}



	public Date getEndDate() {
		return endDate;
	}



	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}



	public MentorCalendar(String timeOfCourse, Mentor mentor, Date statDate, Date endDate) {
		super();
		this.timeOfCourse = timeOfCourse;
		this.mentor = mentor;
		this.statDate = statDate;
		this.endDate = endDate;
	}



	public MentorCalendar() {
		super();
		// TODO Auto-generated constructor stub
	}

	
    
    

}
