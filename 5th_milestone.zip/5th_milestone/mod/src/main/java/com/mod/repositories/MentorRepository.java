package com.mod.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mod.models.Mentor;

public interface MentorRepository extends JpaRepository<Mentor, Long> {

	public List<Mentor> findByUsername(String username);
	public Mentor findMentorById(Long id);
}
