package com.mod.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "Technology")
public class Technology implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
    @Column(name = "technology_name")
    private String name ;
    
    
    @Column(name = "toc")
    private String toc ;
    
    
    @Column(name = "fees")
    private Double fees ;
    
   
    @Column(name = "duration")
    private Double duration ;
    
   
    @Column(name = "prerequites")
    private String prerequites ;
    
    @ManyToMany(cascade = {CascadeType.ALL},fetch = FetchType.EAGER)
    
    @JoinTable(name="mentor_technology",joinColumns = @JoinColumn(name="technology_id"),inverseJoinColumns = @JoinColumn(name="mentorSkill_id"))
    private Set<MentorSkill> mentorSkills=new HashSet<>();
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "technology",fetch = FetchType.EAGER)
    private Set<Training> trainings=new HashSet<>();
    
    
    
    public Set<Training> getTrainings() {
		return trainings;
	}


	public void setTrainings(Set<Training> trainings) {
		this.trainings = trainings;
	}


	public Set<MentorSkill> getMentorSkills() {
		return mentorSkills;
	}


	public void setMentorSkills(Set<MentorSkill> mentorSkills) {
		this.mentorSkills = mentorSkills;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getToc() {
		return toc;
	}


	public void setToc(String toc) {
		this.toc = toc;
	}


	public Double getFees() {
		return fees;
	}


	public void setFees(Double fees) {
		this.fees = fees;
	}


	public Double getDuration() {
		return duration;
	}


	public void setDuration(Double duration) {
		this.duration = duration;
	}


	public String getPrerequites() {
		return prerequites;
	}
	
	public Long getId() {
		return id;
	}


	public void setPrerequites(String prerequites) {
		this.prerequites = prerequites;
	}


	public Technology(String name, String toc, Double fees, Double duration, String prerequites,
			Set<MentorSkill> mentorSkills, Set<Training> trainings) {
		super();
		this.name = name;
		this.toc = toc;
		this.fees = fees;
		this.duration = duration;
		this.prerequites = prerequites;
		this.mentorSkills = mentorSkills;
		this.trainings = trainings;
	}


	public Technology() {
		super();
		// TODO Auto-generated constructor stub
	}
    


}
