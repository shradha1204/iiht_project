package com.mod.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mod.models.Mentor;
import com.mod.models.Technology;
import com.mod.models.User;
import com.mod.repositories.MentorRepository;
import com.mod.repositories.TechnologyRepository;
import com.mod.repositories.UserRepository;

@RestController
@RequestMapping("/api/mod")
public class ModController {
	
	@Autowired
	private MentorRepository mentorRepository;
	
	@Autowired
	private TechnologyRepository technologyRepository;
	
	@Autowired
	private UserRepository userRepository;
	/*
	 * User
	 */
	@GetMapping("/user")
	public List<User> listUser() {
		return userRepository.findAll();
	}
	
	@GetMapping("/user/{name}")
	public List<User> getUserByName(@PathVariable("name")String name) {
		return userRepository.findByUsername(name);
	}
	
	@GetMapping("/user/id/{id}")
	public User getUserById(@PathVariable("id") Long id) {
		User user = userRepository.findUserById(id);
		return user;
	}
	
	@PostMapping("/user/block/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void blockUser(@PathVariable("id") Long id , @RequestBody User user) {
		User user1= userRepository.getOne(id);
		user1.setValid(false);
		userRepository.saveAndFlush(user1);
	}
	
	@PostMapping("/user/unblock/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void unblockUser(@PathVariable("id") Long id , @RequestBody User user) {
		User user1 = userRepository.getOne(id);
		user1.setValid(true);
		userRepository.saveAndFlush(user1);
	}
	
	
	
	/*
	 * Mentor
	 */
	
	@GetMapping("/mentor")
	public List<Mentor> listMentor() {
		return mentorRepository.findAll();
	}
	
	@GetMapping("/mentor/{name}")
	public List<Mentor> getMentorByName(@PathVariable("name")String name) {
		return mentorRepository.findByUsername(name);
	}
	
	@GetMapping("/mentor/id/{id}")
	public Mentor getMentorById(@PathVariable("id") Long id) {
		Mentor mentor = mentorRepository.findMentorById(id);
		return mentor;
	}
	
	@PostMapping("/mentor/block/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void blockMentor(@PathVariable("id") Long id , @RequestBody Mentor mentor) {
		Mentor mentor1 = mentorRepository.getOne(id);
		mentor1.setValid(false);
		mentorRepository.saveAndFlush(mentor1);
	}
	
	@PostMapping("/mentor/unblock/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void unblockMentor(@PathVariable("id") Long id , @RequestBody Mentor mentor) {
		Mentor mentor1 = mentorRepository.getOne(id);
		mentor1.setValid(true);
		mentorRepository.saveAndFlush(mentor1);
	}
	
	@PostMapping("/mentor/new")
	@ResponseStatus(HttpStatus.OK)
	public void createMentor(@RequestBody Mentor mentor) {
		mentorRepository.save(mentor);
	}
	/*
	 * Technology
	 */
	@PostMapping("/technology/new")
	@ResponseStatus(HttpStatus.OK)
	public void createTechnology(@RequestBody Technology technology) {
		technologyRepository.save(technology);
	}
	
	@GetMapping("/technology")
	public List<Technology> listTechnology() {
		return technologyRepository.findAll();
	}
}
